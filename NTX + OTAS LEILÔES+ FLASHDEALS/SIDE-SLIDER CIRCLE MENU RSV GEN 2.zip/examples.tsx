/**
 * 🎨 RSV CIRCLE MENU - EXEMPLOS DE USO
 * 
 * Arquivo: examples.tsx
 * Versão: 2.0
 * Data: 10/12/2025
 * 
 * Este arquivo contém exemplos práticos de como usar o
 * Side-Slider Circle Menu RSV Gen 2 em diferentes cenários.
 */

'use client';

import React, { useState } from 'react';
import CircleMenuRSV from './CircleMenuRSV';
import { UserRole } from './rsv-menu-structure';

// ═══════════════════════════════════════════════════════════
// 📌 EXEMPLO 1: USO BÁSICO
// ═══════════════════════════════════════════════════════════

export function BasicExample() {
  return (
    <div className="min-h-screen bg-gray-50">
      <h1 className="p-8 text-2xl font-bold">Meu App RSV</h1>
      
      {/* Menu com perfil Guest */}
      <CircleMenuRSV 
        currentRole={UserRole.GUEST}
        onNavigate={(path) => {
          console.log('Navegando para:', path);
          // Sua lógica de navegação aqui
        }}
      />
    </div>
  );
}

// ═══════════════════════════════════════════════════════════
// 📌 EXEMPLO 2: COM NEXT.JS APP ROUTER
// ═══════════════════════════════════════════════════════════

'use client';

import { useRouter, usePathname } from 'next/navigation';

export function NextJsExample() {
  const router = useRouter();
  const pathname = usePathname();
  
  // Simular usuário autenticado
  const [currentUser] = useState({
    role: UserRole.HOST,
    name: 'João Silva'
  });

  return (
    <>
      <main className="min-h-screen">
        {/* Seu conteúdo aqui */}
        <h1>Bem-vindo, {currentUser.name}!</h1>
      </main>

      {/* Menu RSV */}
      <CircleMenuRSV 
        currentRole={currentUser.role}
        currentPath={pathname}
        onNavigate={(path) => router.push(path)}
      />
    </>
  );
}

// ═══════════════════════════════════════════════════════════
// 📌 EXEMPLO 3: COM REACT ROUTER
// ═══════════════════════════════════════════════════════════

import { useNavigate, useLocation } from 'react-router-dom';

export function ReactRouterExample() {
  const navigate = useNavigate();
  const location = useLocation();
  
  const [userRole] = useState(UserRole.AGENT);

  return (
    <div className="app">
      <CircleMenuRSV 
        currentRole={userRole}
        currentPath={location.pathname}
        onNavigate={(path) => navigate(path)}
      />
    </div>
  );
}

// ═══════════════════════════════════════════════════════════
// 📌 EXEMPLO 4: COM AUTENTICAÇÃO E MÚLTIPLOS PERFIS
// ═══════════════════════════════════════════════════════════

import { useAuth } from '@/hooks/useAuth';

export function AuthExample() {
  const { user, isAuthenticated } = useAuth();
  
  // Determinar role baseado no usuário
  const getUserRole = (): UserRole => {
    if (!isAuthenticated) return UserRole.GUEST;
    
    switch (user.type) {
      case 'admin': return UserRole.ADMIN;
      case 'host': return UserRole.HOST;
      case 'agency': return UserRole.AGENCY;
      case 'agent': return UserRole.AGENT;
      default: return UserRole.GUEST;
    }
  };

  return (
    <>
      {/* Seu app */}
      <div className="app-content">
        {isAuthenticated ? (
          <h1>Olá, {user.name}!</h1>
        ) : (
          <h1>Bem-vindo ao RSV!</h1>
        )}
      </div>

      {/* Menu adaptativo baseado no usuário */}
      <CircleMenuRSV 
        currentRole={getUserRole()}
        onNavigate={(path) => {
          // Verificar autenticação antes de navegar
          if (path.startsWith('/admin') && !user.isAdmin) {
            alert('Acesso negado!');
            return;
          }
          
          window.location.href = path;
        }}
      />
    </>
  );
}

// ═══════════════════════════════════════════════════════════
// 📌 EXEMPLO 5: COM CONTEXT API
// ═══════════════════════════════════════════════════════════

import { createContext, useContext } from 'react';

// Criar Context
interface AppContextType {
  userRole: UserRole;
  setUserRole: (role: UserRole) => void;
  currentPath: string;
  navigate: (path: string) => void;
}

const AppContext = createContext<AppContextType | null>(null);

// Provider
export function AppProvider({ children }: { children: React.ReactNode }) {
  const [userRole, setUserRole] = useState(UserRole.GUEST);
  const [currentPath, setCurrentPath] = useState('/');

  const navigate = (path: string) => {
    setCurrentPath(path);
    window.history.pushState({}, '', path);
  };

  return (
    <AppContext.Provider value={{ userRole, setUserRole, currentPath, navigate }}>
      {children}
    </AppContext.Provider>
  );
}

// Hook customizado
function useApp() {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within AppProvider');
  return context;
}

// Componente que usa o menu
export function AppWithContext() {
  const { userRole, currentPath, navigate } = useApp();

  return (
    <>
      <div className="app-content">
        <h1>RSV App com Context</h1>
      </div>

      <CircleMenuRSV 
        currentRole={userRole}
        currentPath={currentPath}
        onNavigate={navigate}
      />
    </>
  );
}

// ═══════════════════════════════════════════════════════════
// 📌 EXEMPLO 6: COM THEME CUSTOMIZADO
// ═══════════════════════════════════════════════════════════

export function CustomThemeExample() {
  const customStyles = `
    :root {
      /* Cores customizadas */
      --rsv-primary: #FF6B6B;
      --rsv-secondary: #4ECDC4;
      --rsv-bg-light: rgba(255, 255, 255, 0.95);
      
      /* Typography */
      --rsv-font-family: 'Poppins', sans-serif;
    }
    
    /* Override do FAB */
    .rsv-fab {
      background: linear-gradient(135deg, #FF6B6B, #4ECDC4) !important;
    }
  `;

  return (
    <>
      <style>{customStyles}</style>
      
      <div className="app">
        <h1 style={{ fontFamily: 'Poppins, sans-serif' }}>
          App com Tema Customizado
        </h1>
        
        <CircleMenuRSV 
          currentRole={UserRole.GUEST}
        />
      </div>
    </>
  );
}

// ═══════════════════════════════════════════════════════════
// 📌 EXEMPLO 7: COM LAZY LOADING
// ═══════════════════════════════════════════════════════════

import { lazy, Suspense } from 'react';

const CircleMenuRSVLazy = lazy(() => import('./CircleMenuRSV'));

export function LazyLoadExample() {
  return (
    <div className="app">
      <h1>App com Lazy Loading</h1>
      
      <Suspense 
        fallback={
          <div className="fixed bottom-6 right-6 z-[9999]">
            <div className="w-16 h-16 rounded-full bg-blue-500 animate-pulse" />
          </div>
        }
      >
        <CircleMenuRSVLazy currentRole={UserRole.GUEST} />
      </Suspense>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════
// 📌 EXEMPLO 8: COM TESTES DE MÚLTIPLOS PERFIS
// ═══════════════════════════════════════════════════════════

export function MultiProfileTestExample() {
  const [selectedRole, setSelectedRole] = useState<UserRole>(UserRole.GUEST);

  const roles = [
    { value: UserRole.ADMIN, label: 'Admin', emoji: '⚙️' },
    { value: UserRole.HOST, label: 'Anfitrião', emoji: '🏠' },
    { value: UserRole.AGENCY, label: 'Agência', emoji: '🏢' },
    { value: UserRole.AGENT, label: 'Agente', emoji: '✈️' },
    { value: UserRole.GUEST, label: 'Guest', emoji: '👤' }
  ];

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      {/* Seletor de Perfil */}
      <div className="max-w-md mx-auto mb-8">
        <h2 className="text-xl font-bold mb-4">Testar Perfis de Usuário</h2>
        
        <div className="grid grid-cols-2 gap-3">
          {roles.map(role => (
            <button
              key={role.value}
              onClick={() => setSelectedRole(role.value)}
              className={`
                p-4 rounded-lg border-2 transition-all
                ${selectedRole === role.value 
                  ? 'border-blue-500 bg-blue-50' 
                  : 'border-gray-200 hover:border-gray-300'
                }
              `}
            >
              <div className="text-2xl mb-1">{role.emoji}</div>
              <div className="font-semibold">{role.label}</div>
            </button>
          ))}
        </div>
        
        <div className="mt-6 p-4 bg-blue-50 rounded-lg">
          <p className="text-sm text-blue-800">
            Perfil ativo: <strong>{selectedRole.toUpperCase()}</strong>
          </p>
          <p className="text-xs text-blue-600 mt-1">
            Clique no botão flutuante para ver o menu
          </p>
        </div>
      </div>

      {/* Menu RSV */}
      <CircleMenuRSV 
        currentRole={selectedRole}
        onNavigate={(path) => {
          console.log(`[${selectedRole}] Navegando para:`, path);
        }}
      />
    </div>
  );
}

// ═══════════════════════════════════════════════════════════
// 📌 EXEMPLO 9: COM TRACKING/ANALYTICS
// ═══════════════════════════════════════════════════════════

export function AnalyticsExample() {
  const trackNavigation = (path: string, role: UserRole) => {
    // Enviar para analytics (Google Analytics, Mixpanel, etc)
    if (typeof window !== 'undefined' && window.gtag) {
      window.gtag('event', 'menu_navigation', {
        path: path,
        user_role: role,
        timestamp: new Date().toISOString()
      });
    }
    
    console.log('📊 Analytics:', { path, role });
  };

  return (
    <>
      <div className="app">
        <h1>App com Analytics</h1>
      </div>

      <CircleMenuRSV 
        currentRole={UserRole.GUEST}
        onNavigate={(path) => {
          trackNavigation(path, UserRole.GUEST);
          window.location.href = path;
        }}
      />
    </>
  );
}

// ═══════════════════════════════════════════════════════════
// 📌 EXEMPLO 10: COM INTEGRAÇÃO DE NOTIFICAÇÕES
// ═══════════════════════════════════════════════════════════

import { useEffect } from 'react';

export function NotificationExample() {
  const [notifications, setNotifications] = useState({
    messages: 5,
    bookings: 3,
    groupChats: 2
  });

  // Simular atualização de notificações
  useEffect(() => {
    const interval = setInterval(() => {
      setNotifications(prev => ({
        messages: Math.floor(Math.random() * 10),
        bookings: Math.floor(Math.random() * 5),
        groupChats: Math.floor(Math.random() * 3)
      }));
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  return (
    <>
      <div className="app">
        <h1>App com Notificações</h1>
        
        {/* Exibir badges */}
        <div className="p-4 bg-white rounded-lg shadow">
          <h2 className="font-bold mb-2">Notificações Ativas:</h2>
          <ul className="space-y-1 text-sm">
            <li>📧 Mensagens: {notifications.messages}</li>
            <li>📅 Reservas: {notifications.bookings}</li>
            <li>💬 Chats: {notifications.groupChats}</li>
          </ul>
        </div>
      </div>

      <CircleMenuRSV 
        currentRole={UserRole.GUEST}
        // As badges aparecerão automaticamente no menu
      />
    </>
  );
}

// ═══════════════════════════════════════════════════════════
// 📌 EXEMPLO 11: COM PROTEÇÃO DE ROTAS
// ═══════════════════════════════════════════════════════════

export function ProtectedRoutesExample() {
  const [userRole] = useState(UserRole.HOST);
  
  // Rotas protegidas por perfil
  const isAuthorized = (path: string, role: UserRole): boolean => {
    const adminOnlyRoutes = ['/admin'];
    const hostOnlyRoutes = ['/pricing/smart', '/quality/dashboard'];
    const guestOnlyRoutes = ['/wishlists', '/group-chats'];
    
    if (adminOnlyRoutes.some(r => path.startsWith(r))) {
      return role === UserRole.ADMIN;
    }
    
    if (hostOnlyRoutes.some(r => path.startsWith(r))) {
      return [UserRole.ADMIN, UserRole.HOST, UserRole.AGENCY].includes(role);
    }
    
    if (guestOnlyRoutes.some(r => path.startsWith(r))) {
      return [UserRole.GUEST, UserRole.AGENT].includes(role);
    }
    
    return true; // Rota pública
  };

  return (
    <>
      <div className="app">
        <h1>App com Proteção de Rotas</h1>
      </div>

      <CircleMenuRSV 
        currentRole={userRole}
        onNavigate={(path) => {
          if (!isAuthorized(path, userRole)) {
            alert('🚫 Você não tem permissão para acessar esta página!');
            return;
          }
          
          console.log('✅ Acesso autorizado:', path);
          window.location.href = path;
        }}
      />
    </>
  );
}

// ═══════════════════════════════════════════════════════════
// 📌 EXEMPLO 12: COM SSR (SERVER SIDE RENDERING)
// ═══════════════════════════════════════════════════════════

// app/layout.tsx (Next.js 14+)
import { headers } from 'next/headers';

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  // Detectar role no servidor (cookie, session, etc)
  const headersList = headers();
  const userRole = headersList.get('x-user-role') || UserRole.GUEST;

  return (
    <html lang="pt-BR">
      <body>
        {children}
        
        {/* Menu com role do servidor */}
        <MenuClient initialRole={userRole as UserRole} />
      </body>
    </html>
  );
}

// Componente client
'use client';

function MenuClient({ initialRole }: { initialRole: UserRole }) {
  const [role] = useState(initialRole);
  
  return (
    <CircleMenuRSV 
      currentRole={role}
    />
  );
}

// ═══════════════════════════════════════════════════════════
// 🎯 EXPORT ALL EXAMPLES
// ═══════════════════════════════════════════════════════════

export {
  BasicExample,
  NextJsExample,
  ReactRouterExample,
  AuthExample,
  AppWithContext,
  CustomThemeExample,
  LazyLoadExample,
  MultiProfileTestExample,
  AnalyticsExample,
  NotificationExample,
  ProtectedRoutesExample
};

// ═══════════════════════════════════════════════════════════
// 📚 COMO USAR OS EXEMPLOS
// ═══════════════════════════════════════════════════════════

/**
 * 1. BÁSICO:
 *    - Importe BasicExample
 *    - Renderize em seu App.tsx
 * 
 * 2. COM FRAMEWORK:
 *    - Next.js → NextJsExample
 *    - React Router → ReactRouterExample
 * 
 * 3. COM AUTENTICAÇÃO:
 *    - Use AuthExample
 *    - Integre com seu sistema de auth
 * 
 * 4. COM CONTEXT:
 *    - Envolva app com AppProvider
 *    - Use AppWithContext
 * 
 * 5. CUSTOMIZAÇÃO:
 *    - CustomThemeExample para temas
 *    - Modifique CSS variables
 * 
 * 6. PERFORMANCE:
 *    - LazyLoadExample para code splitting
 * 
 * 7. TESTES:
 *    - MultiProfileTestExample para testar
 *    - Ideal para desenvolvimento
 * 
 * 8. ANALYTICS:
 *    - AnalyticsExample para tracking
 *    - Integre com seu analytics
 * 
 * 9. NOTIFICAÇÕES:
 *    - NotificationExample
 *    - Integre com backend de notificações
 * 
 * 10. SEGURANÇA:
 *     - ProtectedRoutesExample
 *     - Adicione validações customizadas
 */
