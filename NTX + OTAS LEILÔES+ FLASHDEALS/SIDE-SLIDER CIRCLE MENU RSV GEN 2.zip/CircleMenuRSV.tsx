/**
 * 🎨 SIDE-SLIDER CIRCLE MENU RSV GEN 2 - REVOLUCIONÁRIO
 * 
 * Design Philosophy: Neo-Morphic Glassmorphism com elementos circulares flutuantes
 * Inspiração: Apple Vision OS + Fluent Design + Material You
 * Aesthetic: Futuristic, Elegant, Playful
 * 
 * Features:
 * - Menu circular expansível com física de movimento
 * - Glassmorphism com blur e gradientes
 * - Animações suaves com spring physics
 * - Badges animados e pulsantes
 * - Suporte a 5 perfis de usuário
 * - Dark mode nativo
 * - Totalmente acessível (WCAG AA)
 * - Mobile-first e responsivo
 * 
 * @author RSV Team
 * @version 2.0
 * @date 2025-12-10
 */

'use client';

import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { motion, AnimatePresence, useSpring, useMotionValue } from 'framer-motion';
import { 
  X, Menu, ChevronRight, Search, Sparkles, 
  Home, Building, Calendar, Users, BarChart, 
  DollarSign, Award, MessageCircle, HelpCircle,
  CreditCard, Gift, Shield, Key, CheckCircle,
  FileText, Tag, Settings, Sliders
} from 'lucide-react';
import {
  UserRole,
  MenuCategory,
  MenuItem,
  MenuCategoryConfig,
  COMPLETE_MENU,
  MENU_CATEGORIES,
  getMenuByRole,
  getCategoriesByRole,
  getHierarchicalMenu,
  searchMenu,
  getBadgeCount,
  HierarchicalMenu
} from './rsv-menu-structure';

/**
 * ═══════════════════════════════════════════════════════════
 * 🎨 PROPS DO COMPONENTE
 * ═══════════════════════════════════════════════════════════
 */
interface CircleMenuProps {
  currentRole: UserRole;
  currentPath?: string;
  onNavigate?: (path: string) => void;
  className?: string;
}

/**
 * ═══════════════════════════════════════════════════════════
 * 🎨 MAPA DE ÍCONES (Lucide React)
 * ═══════════════════════════════════════════════════════════
 */
const ICON_MAP: Record<string, any> = {
  Home, Building, Calendar, Users, BarChart, 
  DollarSign, Award, MessageCircle, HelpCircle,
  CreditCard, Gift, Shield, Key, CheckCircle,
  FileText, Tag, Settings, Sliders, Menu, Search,
  Sparkles, ChevronRight
};

const getIcon = (iconName: string) => {
  return ICON_MAP[iconName] || Menu;
};

/**
 * ═══════════════════════════════════════════════════════════
 * 🎯 COMPONENTE PRINCIPAL
 * ═══════════════════════════════════════════════════════════
 */
export function CircleMenuRSV({ 
  currentRole, 
  currentPath = '/',
  onNavigate,
  className = '' 
}: CircleMenuProps) {
  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  // 🔧 STATES
  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  const [isOpen, setIsOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<MenuCategory | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [hoveredItem, setHoveredItem] = useState<string | null>(null);
  const [isDarkMode, setIsDarkMode] = useState(false);

  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  // 📊 DADOS COMPUTADOS
  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  const hierarchicalMenu = useMemo(
    () => getHierarchicalMenu(currentRole),
    [currentRole]
  );

  const availableCategories = useMemo(
    () => getCategoriesByRole(currentRole),
    [currentRole]
  );

  const searchResults = useMemo(
    () => searchQuery ? searchMenu(searchQuery, currentRole) : [],
    [searchQuery, currentRole]
  );

  const activeItems = useMemo(() => {
    if (searchQuery) return searchResults;
    if (selectedCategory) {
      const group = hierarchicalMenu.find(g => g.category.id === selectedCategory);
      return group?.items || [];
    }
    return [];
  }, [searchQuery, selectedCategory, hierarchicalMenu, searchResults]);

  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  // 🎭 HANDLERS
  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  const handleToggleMenu = useCallback(() => {
    setIsOpen(prev => !prev);
    if (!isOpen) {
      setSelectedCategory(null);
      setSearchQuery('');
    }
  }, [isOpen]);

  const handleSelectCategory = useCallback((category: MenuCategory) => {
    setSelectedCategory(category);
    setSearchQuery('');
  }, []);

  const handleNavigate = useCallback((path: string) => {
    onNavigate?.(path);
    setIsOpen(false);
    setSelectedCategory(null);
    setSearchQuery('');
  }, [onNavigate]);

  const handleBack = useCallback(() => {
    if (searchQuery) {
      setSearchQuery('');
    } else if (selectedCategory) {
      setSelectedCategory(null);
    }
  }, [searchQuery, selectedCategory]);

  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  // ⌨️ KEYBOARD SHORTCUTS
  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Cmd/Ctrl + K para abrir menu
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        handleToggleMenu();
      }
      // Esc para fechar
      if (e.key === 'Escape' && isOpen) {
        if (selectedCategory || searchQuery) {
          handleBack();
        } else {
          setIsOpen(false);
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, selectedCategory, searchQuery, handleToggleMenu, handleBack]);

  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  // 🎨 TEMA
  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  useEffect(() => {
    // Detectar preferência do sistema
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    setIsDarkMode(prefersDark);
  }, []);

  const theme = isDarkMode ? {
    bg: 'rgba(15, 23, 42, 0.85)',
    bgSecondary: 'rgba(30, 41, 59, 0.85)',
    text: '#F1F5F9',
    textSecondary: '#CBD5E1',
    border: 'rgba(148, 163, 184, 0.1)',
    accent: '#3B82F6',
    shadow: '0 25px 50px -12px rgba(0, 0, 0, 0.5)',
    glassBlur: 'blur(20px)',
  } : {
    bg: 'rgba(255, 255, 255, 0.85)',
    bgSecondary: 'rgba(248, 250, 252, 0.85)',
    text: '#0F172A',
    textSecondary: '#64748B',
    border: 'rgba(148, 163, 184, 0.2)',
    accent: '#3B82F6',
    shadow: '0 25px 50px -12px rgba(0, 0, 0, 0.25)',
    glassBlur: 'blur(20px)',
  };

  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  // 🎬 ANIMAÇÕES
  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  const menuVariants = {
    closed: {
      x: '-100%',
      transition: {
        type: 'spring',
        stiffness: 300,
        damping: 30
      }
    },
    open: {
      x: 0,
      transition: {
        type: 'spring',
        stiffness: 300,
        damping: 30
      }
    }
  };

  const overlayVariants = {
    closed: { opacity: 0 },
    open: { opacity: 1 }
  };

  const categoryVariants = {
    hidden: { scale: 0.8, opacity: 0 },
    visible: (i: number) => ({
      scale: 1,
      opacity: 1,
      transition: {
        type: 'spring',
        stiffness: 300,
        damping: 25,
        delay: i * 0.03
      }
    })
  };

  const itemVariants = {
    hidden: { x: -20, opacity: 0 },
    visible: (i: number) => ({
      x: 0,
      opacity: 1,
      transition: {
        type: 'spring',
        stiffness: 400,
        damping: 30,
        delay: i * 0.02
      }
    })
  };

  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  // 🎨 RENDER
  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  return (
    <>
      {/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */}
      {/* 🔘 BOTÃO FLUTUANTE (FAB) */}
      {/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */}
      <motion.button
        onClick={handleToggleMenu}
        className={`
          fixed bottom-6 right-6 z-[9999]
          w-16 h-16 rounded-full
          flex items-center justify-center
          shadow-2xl
          ${className}
        `}
        style={{
          background: `linear-gradient(135deg, ${theme.accent}, #8B5CF6)`,
          backdropFilter: theme.glassBlur,
          boxShadow: theme.shadow
        }}
        whileHover={{ scale: 1.1, rotate: 180 }}
        whileTap={{ scale: 0.95 }}
        aria-label={isOpen ? "Fechar menu" : "Abrir menu"}
        aria-expanded={isOpen}
      >
        <motion.div
          animate={{ rotate: isOpen ? 180 : 0 }}
          transition={{ duration: 0.3 }}
        >
          {isOpen ? (
            <X className="w-7 h-7 text-white" />
          ) : (
            <Menu className="w-7 h-7 text-white" />
          )}
        </motion.div>

        {/* Pulse animation quando fechado */}
        {!isOpen && (
          <motion.div
            className="absolute inset-0 rounded-full"
            style={{
              background: `linear-gradient(135deg, ${theme.accent}, #8B5CF6)`,
              opacity: 0.3
            }}
            animate={{
              scale: [1, 1.3, 1],
              opacity: [0.3, 0, 0.3]
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          />
        )}
      </motion.button>

      {/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */}
      {/* 🌑 OVERLAY */}
      {/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            className="fixed inset-0 z-[9998]"
            style={{
              backgroundColor: isDarkMode 
                ? 'rgba(0, 0, 0, 0.7)' 
                : 'rgba(0, 0, 0, 0.4)',
              backdropFilter: 'blur(8px)'
            }}
            variants={overlayVariants}
            initial="closed"
            animate="open"
            exit="closed"
            onClick={handleToggleMenu}
            aria-hidden="true"
          />
        )}
      </AnimatePresence>

      {/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */}
      {/* 🎨 MENU PRINCIPAL */}
      {/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            className="fixed left-0 top-0 bottom-0 z-[9999] w-full max-w-md"
            style={{
              background: theme.bg,
              backdropFilter: theme.glassBlur,
              borderRight: `1px solid ${theme.border}`,
              boxShadow: theme.shadow
            }}
            variants={menuVariants}
            initial="closed"
            animate="open"
            exit="closed"
            role="dialog"
            aria-modal="true"
            aria-label="Menu de navegação"
          >
            {/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */}
            {/* 📌 HEADER */}
            {/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */}
            <div 
              className="p-6 border-b"
              style={{ borderColor: theme.border }}
            >
              {/* Voltar / Fechar */}
              <div className="flex items-center justify-between mb-4">
                {(selectedCategory || searchQuery) ? (
                  <button
                    onClick={handleBack}
                    className="flex items-center gap-2 transition-opacity hover:opacity-70"
                    style={{ color: theme.textSecondary }}
                    aria-label="Voltar"
                  >
                    <ChevronRight className="w-5 h-5 rotate-180" />
                    <span className="font-medium">Voltar</span>
                  </button>
                ) : (
                  <div 
                    className="flex items-center gap-3"
                    style={{ color: theme.text }}
                  >
                    <div 
                      className="w-10 h-10 rounded-full flex items-center justify-center"
                      style={{
                        background: `linear-gradient(135deg, ${theme.accent}, #8B5CF6)`
                      }}
                    >
                      <Sparkles className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <h2 className="text-lg font-bold">RSV Menu</h2>
                      <p 
                        className="text-xs"
                        style={{ color: theme.textSecondary }}
                      >
                        {currentRole.toUpperCase()}
                      </p>
                    </div>
                  </div>
                )}

                <button
                  onClick={handleToggleMenu}
                  className="w-8 h-8 rounded-full flex items-center justify-center transition-colors"
                  style={{
                    background: theme.bgSecondary,
                    color: theme.textSecondary
                  }}
                  aria-label="Fechar menu"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Search Bar */}
              <div 
                className="relative"
                style={{
                  background: theme.bgSecondary,
                  borderRadius: '12px',
                  border: `1px solid ${theme.border}`
                }}
              >
                <Search 
                  className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5"
                  style={{ color: theme.textSecondary }}
                />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Buscar no menu... (⌘K)"
                  className="w-full py-3 pl-11 pr-4 bg-transparent outline-none"
                  style={{ color: theme.text }}
                  aria-label="Buscar no menu"
                />
              </div>
            </div>

            {/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */}
            {/* 📋 CONTEÚDO */}
            {/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */}
            <div className="flex-1 overflow-y-auto p-6 space-y-4">
              <AnimatePresence mode="wait">
                {/* Resultado de Busca ou Itens da Categoria */}
                {(searchQuery || selectedCategory) ? (
                  <motion.div
                    key="items"
                    initial="hidden"
                    animate="visible"
                    exit="hidden"
                    className="space-y-2"
                  >
                    {activeItems.length > 0 ? (
                      activeItems.map((item, index) => (
                        <MenuItem
                          key={item.id}
                          item={item}
                          index={index}
                          isActive={currentPath === item.path}
                          theme={theme}
                          onNavigate={handleNavigate}
                          isHovered={hoveredItem === item.id}
                          onHover={setHoveredItem}
                        />
                      ))
                    ) : (
                      <div 
                        className="text-center py-12"
                        style={{ color: theme.textSecondary }}
                      >
                        <Search className="w-12 h-12 mx-auto mb-3 opacity-50" />
                        <p>Nenhum resultado encontrado</p>
                      </div>
                    )}
                  </motion.div>
                ) : (
                  /* Grid de Categorias */
                  <motion.div
                    key="categories"
                    initial="hidden"
                    animate="visible"
                    exit="hidden"
                    className="grid grid-cols-2 gap-3"
                  >
                    {availableCategories.map((category, index) => (
                      <CategoryCard
                        key={category.id}
                        category={category}
                        index={index}
                        theme={theme}
                        onSelect={handleSelectCategory}
                        itemCount={
                          hierarchicalMenu.find(g => g.category.id === category.id)?.items.length || 0
                        }
                      />
                    ))}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */}
            {/* 🔧 FOOTER */}
            {/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */}
            <div 
              className="p-4 border-t text-center text-xs"
              style={{ 
                borderColor: theme.border,
                color: theme.textSecondary 
              }}
            >
              <p>RSV Gen 2 • Versão 2.0 Revolucionária</p>
              <p className="mt-1">⌘K para abrir • ESC para fechar</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}

/**
 * ═══════════════════════════════════════════════════════════
 * 🎨 COMPONENTE: CATEGORY CARD
 * ═══════════════════════════════════════════════════════════
 */
interface CategoryCardProps {
  category: MenuCategoryConfig;
  index: number;
  theme: any;
  onSelect: (category: MenuCategory) => void;
  itemCount: number;
}

function CategoryCard({ category, index, theme, onSelect, itemCount }: CategoryCardProps) {
  const Icon = getIcon(category.icon);

  return (
    <motion.button
      custom={index}
      variants={categoryVariants}
      initial="hidden"
      animate="visible"
      whileHover={{ scale: 1.05, y: -5 }}
      whileTap={{ scale: 0.95 }}
      onClick={() => onSelect(category.id)}
      className="relative p-4 rounded-2xl text-left overflow-hidden"
      style={{
        background: `linear-gradient(135deg, ${category.gradientFrom}15, ${category.gradientTo}15)`,
        border: `1px solid ${category.color}30`,
        boxShadow: `0 4px 20px ${category.color}20`
      }}
      aria-label={`Ver ${category.label}`}
    >
      {/* Gradiente de fundo animado */}
      <motion.div
        className="absolute inset-0 opacity-0"
        style={{
          background: `linear-gradient(135deg, ${category.gradientFrom}30, ${category.gradientTo}30)`
        }}
        whileHover={{ opacity: 1 }}
        transition={{ duration: 0.3 }}
      />

      {/* Conteúdo */}
      <div className="relative z-10">
        {/* Ícone */}
        <div 
          className="w-12 h-12 rounded-xl flex items-center justify-center mb-3"
          style={{
            background: `linear-gradient(135deg, ${category.gradientFrom}, ${category.gradientTo})`,
            boxShadow: `0 4px 12px ${category.color}40`
          }}
        >
          <span className="text-2xl">{category.emoji}</span>
        </div>

        {/* Texto */}
        <h3 
          className="font-bold text-sm mb-1"
          style={{ color: theme.text }}
        >
          {category.label}
        </h3>
        <p 
          className="text-xs mb-2"
          style={{ color: theme.textSecondary }}
        >
          {category.description}
        </p>

        {/* Badge de contagem */}
        <div 
          className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium"
          style={{
            background: `${category.color}20`,
            color: category.color
          }}
        >
          <span>{itemCount}</span>
          <span>itens</span>
        </div>
      </div>

      {/* Ícone de seta */}
      <ChevronRight 
        className="absolute top-3 right-3 w-4 h-4"
        style={{ color: theme.textSecondary }}
      />
    </motion.button>
  );
}

/**
 * ═══════════════════════════════════════════════════════════
 * 🎨 COMPONENTE: MENU ITEM
 * ═══════════════════════════════════════════════════════════
 */
interface MenuItemProps {
  item: MenuItem;
  index: number;
  isActive: boolean;
  theme: any;
  onNavigate: (path: string) => void;
  isHovered: boolean;
  onHover: (id: string | null) => void;
}

function MenuItem({ item, index, isActive, theme, onNavigate, isHovered, onHover }: MenuItemProps) {
  const Icon = getIcon(item.icon);
  const badgeCount = item.badge ? getBadgeCount(item.id) : 0;

  return (
    <motion.button
      custom={index}
      variants={itemVariants}
      initial="hidden"
      animate="visible"
      whileHover={{ x: 8 }}
      onClick={() => onNavigate(item.path)}
      onMouseEnter={() => onHover(item.id)}
      onMouseLeave={() => onHover(null)}
      className="w-full flex items-center gap-4 p-4 rounded-xl transition-all"
      style={{
        background: isActive 
          ? `linear-gradient(90deg, ${item.color}20, transparent)`
          : isHovered
          ? theme.bgSecondary
          : 'transparent',
        border: isActive 
          ? `1px solid ${item.color}40`
          : '1px solid transparent'
      }}
      aria-current={isActive ? 'page' : undefined}
    >
      {/* Ícone com gradiente */}
      <div 
        className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 relative"
        style={{
          background: isActive
            ? `linear-gradient(135deg, ${item.color}, ${item.gradientTo || item.color})`
            : theme.bgSecondary,
          color: isActive ? '#FFFFFF' : item.color
        }}
      >
        {item.emoji ? (
          <span className="text-xl">{item.emoji}</span>
        ) : (
          <Icon className="w-5 h-5" />
        )}

        {/* Badge Count */}
        {badgeCount > 0 && (
          <motion.div
            className="absolute -top-1 -right-1 w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold"
            style={{
              background: '#EF4444',
              color: '#FFFFFF',
              boxShadow: '0 2px 8px rgba(239, 68, 68, 0.4)'
            }}
            animate={{
              scale: [1, 1.2, 1]
            }}
            transition={{
              duration: 2,
              repeat: Infinity
            }}
          >
            {badgeCount}
          </motion.div>
        )}

        {/* Badges de status */}
        {item.isNew && (
          <div 
            className="absolute -top-1 -left-1 px-1.5 py-0.5 rounded text-[10px] font-bold"
            style={{
              background: '#10B981',
              color: '#FFFFFF'
            }}
          >
            NEW
          </div>
        )}
        {item.isHot && (
          <div 
            className="absolute -bottom-1 -right-1 text-xs"
          >
            🔥
          </div>
        )}
      </div>

      {/* Texto */}
      <div className="flex-1 text-left">
        <div 
          className="font-semibold text-sm"
          style={{ color: theme.text }}
        >
          {item.label}
        </div>
        {item.description && (
          <div 
            className="text-xs mt-0.5"
            style={{ color: theme.textSecondary }}
          >
            {item.description}
          </div>
        )}
      </div>

      {/* Seta de navegação */}
      <ChevronRight 
        className="w-5 h-5 transition-transform"
        style={{ 
          color: theme.textSecondary,
          transform: isHovered ? 'translateX(4px)' : 'translateX(0)'
        }}
      />
    </motion.button>
  );
}

/**
 * ═══════════════════════════════════════════════════════════
 * 🎨 EXPORT DEFAULT
 * ═══════════════════════════════════════════════════════════
 */
export default CircleMenuRSV;
