// 🎨 RSV GEN 2 - ESTRUTURA COMPLETA DO MENU CIRCULAR
// Data: 10/12/2025
// Versão: 2.0 REVOLUCIONÁRIA

/**
 * PERFIS DE USUÁRIO DO SISTEMA RSV
 */
export enum UserRole {
  ADMIN = 'admin',
  HOST = 'host',           // Anfitrião
  AGENCY = 'agency',       // Agência
  AGENT = 'agent',         // Agente de Viagens
  GUEST = 'guest'          // Usuário Final/Viajante
}

/**
 * TIPOS DE CATEGORIAS DO MENU
 */
export enum MenuCategory {
  // Categorias Principais
  HOME = 'home',
  PROPERTIES = 'properties',
  BOOKINGS = 'bookings',
  GROUP_TRAVEL = 'group_travel',
  
  // Gestão e Analytics
  ANALYTICS = 'analytics',
  PRICING = 'pricing',
  QUALITY = 'quality',
  CRM = 'crm',
  
  // Comunicação
  COMMUNICATION = 'communication',
  SUPPORT = 'support',
  
  // Financeiro
  PAYMENTS = 'payments',
  LOYALTY = 'loyalty',
  INSURANCE = 'insurance',
  
  // Operacional
  CHECKIN = 'checkin',
  VERIFICATION = 'verification',
  
  // Conteúdo
  CONTENT = 'content',
  PROMOTIONS = 'promotions',
  
  // Administrativo
  ADMIN = 'admin',
  SETTINGS = 'settings'
}

/**
 * INTERFACE DO ITEM DE MENU
 */
export interface MenuItem {
  id: string;
  label: string;
  icon: string;
  emoji?: string;
  path: string;
  category: MenuCategory;
  roles: UserRole[];
  badge?: number | string;
  isNew?: boolean;
  isHot?: boolean;
  children?: MenuItem[];
  description?: string;
  color?: string;
  gradientFrom?: string;
  gradientTo?: string;
}

/**
 * INTERFACE DA CATEGORIA DO MENU
 */
export interface MenuCategoryConfig {
  id: MenuCategory;
  label: string;
  icon: string;
  emoji: string;
  color: string;
  gradientFrom: string;
  gradientTo: string;
  description: string;
  roles: UserRole[];
}

/**
 * ═══════════════════════════════════════════════════════════
 * 🎨 CONFIGURAÇÃO DAS CATEGORIAS
 * ═══════════════════════════════════════════════════════════
 */
export const MENU_CATEGORIES: MenuCategoryConfig[] = [
  {
    id: MenuCategory.HOME,
    label: 'Início',
    icon: 'Home',
    emoji: '🏠',
    color: '#3B82F6',
    gradientFrom: '#3B82F6',
    gradientTo: '#1D4ED8',
    description: 'Página inicial e visão geral',
    roles: [UserRole.ADMIN, UserRole.HOST, UserRole.AGENCY, UserRole.AGENT, UserRole.GUEST]
  },
  {
    id: MenuCategory.PROPERTIES,
    label: 'Propriedades',
    icon: 'Building',
    emoji: '🏨',
    color: '#10B981',
    gradientFrom: '#10B981',
    gradientTo: '#059669',
    description: 'Hotéis e propriedades',
    roles: [UserRole.ADMIN, UserRole.HOST, UserRole.AGENCY, UserRole.AGENT, UserRole.GUEST]
  },
  {
    id: MenuCategory.BOOKINGS,
    label: 'Reservas',
    icon: 'Calendar',
    emoji: '📅',
    color: '#F59E0B',
    gradientFrom: '#F59E0B',
    gradientTo: '#D97706',
    description: 'Gerenciar reservas',
    roles: [UserRole.ADMIN, UserRole.HOST, UserRole.AGENCY, UserRole.AGENT, UserRole.GUEST]
  },
  {
    id: MenuCategory.GROUP_TRAVEL,
    label: 'Viagens em Grupo',
    icon: 'Users',
    emoji: '👥',
    color: '#8B5CF6',
    gradientFrom: '#8B5CF6',
    gradientTo: '#7C3AED',
    description: 'Wishlists, divisão e chat',
    roles: [UserRole.GUEST, UserRole.AGENT, UserRole.AGENCY]
  },
  {
    id: MenuCategory.ANALYTICS,
    label: 'Analytics',
    icon: 'BarChart',
    emoji: '📊',
    color: '#06B6D4',
    gradientFrom: '#06B6D4',
    gradientTo: '#0891B2',
    description: 'Dashboards e relatórios',
    roles: [UserRole.ADMIN, UserRole.HOST, UserRole.AGENCY]
  },
  {
    id: MenuCategory.PRICING,
    label: 'Precificação',
    icon: 'DollarSign',
    emoji: '💰',
    color: '#EF4444',
    gradientFrom: '#EF4444',
    gradientTo: '#DC2626',
    description: 'Smart Pricing e competidores',
    roles: [UserRole.ADMIN, UserRole.HOST, UserRole.AGENCY]
  },
  {
    id: MenuCategory.QUALITY,
    label: 'Qualidade',
    icon: 'Award',
    emoji: '🏆',
    color: '#F59E0B',
    gradientFrom: '#F59E0B',
    gradientTo: '#D97706',
    description: 'Top Host e rankings',
    roles: [UserRole.ADMIN, UserRole.HOST]
  },
  {
    id: MenuCategory.CRM,
    label: 'CRM',
    icon: 'Users',
    emoji: '👤',
    color: '#6366F1',
    gradientFrom: '#6366F1',
    gradientTo: '#4F46E5',
    description: 'Relacionamento com clientes',
    roles: [UserRole.ADMIN, UserRole.AGENCY, UserRole.AGENT]
  },
  {
    id: MenuCategory.COMMUNICATION,
    label: 'Comunicação',
    icon: 'MessageCircle',
    emoji: '💬',
    color: '#14B8A6',
    gradientFrom: '#14B8A6',
    gradientTo: '#0D9488',
    description: 'Mensagens e notificações',
    roles: [UserRole.ADMIN, UserRole.HOST, UserRole.AGENCY, UserRole.AGENT, UserRole.GUEST]
  },
  {
    id: MenuCategory.SUPPORT,
    label: 'Suporte',
    icon: 'HelpCircle',
    emoji: '🎫',
    color: '#F97316',
    gradientFrom: '#F97316',
    gradientTo: '#EA580C',
    description: 'Tickets e ajuda',
    roles: [UserRole.ADMIN, UserRole.HOST, UserRole.AGENCY, UserRole.AGENT, UserRole.GUEST]
  },
  {
    id: MenuCategory.PAYMENTS,
    label: 'Pagamentos',
    icon: 'CreditCard',
    emoji: '💳',
    color: '#10B981',
    gradientFrom: '#10B981',
    gradientTo: '#059669',
    description: 'Métodos e divisão',
    roles: [UserRole.ADMIN, UserRole.HOST, UserRole.AGENCY, UserRole.GUEST]
  },
  {
    id: MenuCategory.LOYALTY,
    label: 'Fidelidade',
    icon: 'Gift',
    emoji: '🎁',
    color: '#EC4899',
    gradientFrom: '#EC4899',
    gradientTo: '#DB2777',
    description: 'Pontos e recompensas',
    roles: [UserRole.ADMIN, UserRole.GUEST]
  },
  {
    id: MenuCategory.INSURANCE,
    label: 'Seguros',
    icon: 'Shield',
    emoji: '🛡️',
    color: '#8B5CF6',
    gradientFrom: '#8B5CF6',
    gradientTo: '#7C3AED',
    description: 'Proteção de viagem',
    roles: [UserRole.ADMIN, UserRole.GUEST, UserRole.AGENT]
  },
  {
    id: MenuCategory.CHECKIN,
    label: 'Check-in',
    icon: 'Key',
    emoji: '🔑',
    color: '#06B6D4',
    gradientFrom: '#06B6D4',
    gradientTo: '#0891B2',
    description: 'Check-in digital',
    roles: [UserRole.ADMIN, UserRole.HOST, UserRole.GUEST]
  },
  {
    id: MenuCategory.VERIFICATION,
    label: 'Verificação',
    icon: 'CheckCircle',
    emoji: '✅',
    color: '#10B981',
    gradientFrom: '#10B981',
    gradientTo: '#059669',
    description: 'Validação de usuários',
    roles: [UserRole.ADMIN, UserRole.HOST]
  },
  {
    id: MenuCategory.CONTENT,
    label: 'Conteúdo',
    icon: 'FileText',
    emoji: '📄',
    color: '#6366F1',
    gradientFrom: '#6366F1',
    gradientTo: '#4F46E5',
    description: 'CMS e páginas',
    roles: [UserRole.ADMIN, UserRole.AGENCY]
  },
  {
    id: MenuCategory.PROMOTIONS,
    label: 'Promoções',
    icon: 'Tag',
    emoji: '🏷️',
    color: '#EF4444',
    gradientFrom: '#EF4444',
    gradientTo: '#DC2626',
    description: 'Ofertas e cupons',
    roles: [UserRole.ADMIN, UserRole.HOST, UserRole.AGENCY, UserRole.GUEST]
  },
  {
    id: MenuCategory.ADMIN,
    label: 'Administração',
    icon: 'Settings',
    emoji: '⚙️',
    color: '#64748B',
    gradientFrom: '#64748B',
    gradientTo: '#475569',
    description: 'Gestão do sistema',
    roles: [UserRole.ADMIN]
  },
  {
    id: MenuCategory.SETTINGS,
    label: 'Configurações',
    icon: 'Sliders',
    emoji: '🔧',
    color: '#6B7280',
    gradientFrom: '#6B7280',
    gradientTo: '#4B5563',
    description: 'Preferências e perfil',
    roles: [UserRole.ADMIN, UserRole.HOST, UserRole.AGENCY, UserRole.AGENT, UserRole.GUEST]
  }
];

/**
 * ═══════════════════════════════════════════════════════════
 * 🎯 MENU COMPLETO - TODOS OS 50+ ITENS MAPEADOS
 * ═══════════════════════════════════════════════════════════
 */
export const COMPLETE_MENU: MenuItem[] = [
  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  // 🏠 HOME
  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  {
    id: 'home',
    label: 'Início',
    icon: 'Home',
    emoji: '🏠',
    path: '/',
    category: MenuCategory.HOME,
    roles: [UserRole.ADMIN, UserRole.HOST, UserRole.AGENCY, UserRole.AGENT, UserRole.GUEST],
    description: 'Página inicial',
    color: '#3B82F6'
  },
  {
    id: 'dashboard',
    label: 'Dashboard',
    icon: 'LayoutDashboard',
    emoji: '📊',
    path: '/dashboard-rsv',
    category: MenuCategory.HOME,
    roles: [UserRole.ADMIN, UserRole.HOST, UserRole.AGENCY],
    description: 'Dashboard principal',
    color: '#3B82F6'
  },

  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  // 🏨 PROPRIEDADES
  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  {
    id: 'properties',
    label: 'Hotéis',
    icon: 'Building',
    emoji: '🏨',
    path: '/hoteis',
    category: MenuCategory.PROPERTIES,
    roles: [UserRole.ADMIN, UserRole.HOST, UserRole.AGENCY, UserRole.AGENT, UserRole.GUEST],
    description: 'Lista de hotéis',
    color: '#10B981'
  },
  {
    id: 'search',
    label: 'Buscar',
    icon: 'Search',
    emoji: '🔍',
    path: '/buscar',
    category: MenuCategory.PROPERTIES,
    roles: [UserRole.ADMIN, UserRole.HOST, UserRole.AGENCY, UserRole.AGENT, UserRole.GUEST],
    description: 'Busca avançada',
    color: '#10B981'
  },
  {
    id: 'attractions',
    label: 'Atrações',
    icon: 'MapPin',
    emoji: '🏞️',
    path: '/atracoes',
    category: MenuCategory.PROPERTIES,
    roles: [UserRole.AGENT, UserRole.GUEST],
    description: 'Atrações turísticas',
    color: '#10B981'
  },
  {
    id: 'tickets',
    label: 'Ingressos',
    icon: 'Ticket',
    emoji: '🎟️',
    path: '/ingressos',
    category: MenuCategory.PROPERTIES,
    roles: [UserRole.AGENT, UserRole.GUEST],
    description: 'Ingressos para parques',
    color: '#10B981'
  },
  {
    id: 'search-hosts',
    label: 'Buscar Anfitriões',
    icon: 'UserSearch',
    emoji: '🔎',
    path: '/buscar-hosts',
    category: MenuCategory.PROPERTIES,
    roles: [UserRole.ADMIN, UserRole.AGENCY, UserRole.AGENT],
    description: 'Encontrar hosts',
    color: '#10B981'
  },

  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  // 📅 RESERVAS
  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  {
    id: 'my-bookings',
    label: 'Minhas Reservas',
    icon: 'CalendarCheck',
    emoji: '📋',
    path: '/minhas-reservas',
    category: MenuCategory.BOOKINGS,
    roles: [UserRole.ADMIN, UserRole.HOST, UserRole.AGENCY, UserRole.AGENT, UserRole.GUEST],
    description: 'Gerenciar reservas',
    color: '#F59E0B',
    badge: 'badge'
  },
  {
    id: 'trips',
    label: 'Viagens',
    icon: 'Plane',
    emoji: '✈️',
    path: '/trips',
    category: MenuCategory.BOOKINGS,
    roles: [UserRole.GUEST, UserRole.AGENT],
    description: 'Minhas viagens',
    color: '#F59E0B'
  },
  {
    id: 'reviews',
    label: 'Avaliações',
    icon: 'Star',
    emoji: '⭐',
    path: '/avaliacoes',
    category: MenuCategory.BOOKINGS,
    roles: [UserRole.ADMIN, UserRole.HOST, UserRole.GUEST],
    description: 'Reviews e ratings',
    color: '#F59E0B'
  },

  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  // 👥 VIAGENS EM GRUPO
  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  {
    id: 'group-travel',
    label: 'Viagens em Grupo',
    icon: 'Users',
    emoji: '👥',
    path: '/viagens-grupo',
    category: MenuCategory.GROUP_TRAVEL,
    roles: [UserRole.GUEST, UserRole.AGENT],
    description: 'Dashboard de grupo',
    color: '#8B5CF6',
    isHot: true
  },
  {
    id: 'wishlists',
    label: 'Wishlists',
    icon: 'Heart',
    emoji: '💝',
    path: '/wishlists',
    category: MenuCategory.GROUP_TRAVEL,
    roles: [UserRole.GUEST, UserRole.AGENT],
    description: 'Listas compartilhadas',
    color: '#8B5CF6'
  },
  {
    id: 'group-chats',
    label: 'Chat em Grupo',
    icon: 'MessageSquare',
    emoji: '💬',
    path: '/group-chats',
    category: MenuCategory.GROUP_TRAVEL,
    roles: [UserRole.GUEST, UserRole.AGENT],
    description: 'Conversas de grupo',
    color: '#8B5CF6',
    badge: 'badge'
  },

  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  // 📊 ANALYTICS
  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  {
    id: 'analytics',
    label: 'Analytics',
    icon: 'TrendingUp',
    emoji: '📈',
    path: '/analytics',
    category: MenuCategory.ANALYTICS,
    roles: [UserRole.ADMIN, UserRole.HOST, UserRole.AGENCY],
    description: 'Dashboard analytics',
    color: '#06B6D4'
  },
  {
    id: 'revenue-forecast',
    label: 'Previsão de Receita',
    icon: 'LineChart',
    emoji: '💹',
    path: '/analytics/revenue-forecast',
    category: MenuCategory.ANALYTICS,
    roles: [UserRole.ADMIN, UserRole.HOST, UserRole.AGENCY],
    description: 'Forecast de revenue',
    color: '#06B6D4'
  },
  {
    id: 'dashboard-stats',
    label: 'Estatísticas',
    icon: 'BarChart3',
    emoji: '📊',
    path: '/dashboard-estatisticas',
    category: MenuCategory.ANALYTICS,
    roles: [UserRole.ADMIN, UserRole.HOST, UserRole.AGENCY],
    description: 'Dashboard de stats',
    color: '#06B6D4'
  },

  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  // 💰 PRICING
  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  {
    id: 'smart-pricing',
    label: 'Smart Pricing',
    icon: 'Zap',
    emoji: '⚡',
    path: '/pricing/smart',
    category: MenuCategory.PRICING,
    roles: [UserRole.ADMIN, UserRole.HOST, UserRole.AGENCY],
    description: 'Precificação IA',
    color: '#EF4444',
    isNew: true
  },
  {
    id: 'competitors',
    label: 'Competidores',
    icon: 'Target',
    emoji: '🎯',
    path: '/pricing/competitors',
    category: MenuCategory.PRICING,
    roles: [UserRole.ADMIN, UserRole.HOST, UserRole.AGENCY],
    description: 'Análise de mercado',
    color: '#EF4444'
  },

  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  // 🏆 QUALIDADE
  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  {
    id: 'quality-dashboard',
    label: 'Dashboard Quality',
    icon: 'Award',
    emoji: '🏆',
    path: '/quality/dashboard',
    category: MenuCategory.QUALITY,
    roles: [UserRole.ADMIN, UserRole.HOST],
    description: 'Qualidade do host',
    color: '#F59E0B',
    isNew: true
  },
  {
    id: 'leaderboard',
    label: 'Ranking',
    icon: 'Trophy',
    emoji: '🥇',
    path: '/quality/leaderboard',
    category: MenuCategory.QUALITY,
    roles: [UserRole.ADMIN, UserRole.HOST],
    description: 'Top hosts',
    color: '#F59E0B'
  },

  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  // 👤 CRM
  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  {
    id: 'crm',
    label: 'CRM',
    icon: 'Users',
    emoji: '📇',
    path: '/crm',
    category: MenuCategory.CRM,
    roles: [UserRole.ADMIN, UserRole.AGENCY, UserRole.AGENT],
    description: 'Gestão de clientes',
    color: '#6366F1'
  },

  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  // 💬 COMUNICAÇÃO
  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  {
    id: 'messages',
    label: 'Mensagens',
    icon: 'Mail',
    emoji: '📧',
    path: '/mensagens',
    category: MenuCategory.COMMUNICATION,
    roles: [UserRole.ADMIN, UserRole.HOST, UserRole.AGENCY, UserRole.AGENT, UserRole.GUEST],
    description: 'Central de mensagens',
    color: '#14B8A6',
    badge: 'badge'
  },
  {
    id: 'notifications',
    label: 'Notificações',
    icon: 'Bell',
    emoji: '🔔',
    path: '/notificacoes',
    category: MenuCategory.COMMUNICATION,
    roles: [UserRole.ADMIN, UserRole.HOST, UserRole.AGENCY, UserRole.AGENT, UserRole.GUEST],
    description: 'Central de notificações',
    color: '#14B8A6',
    badge: 'badge'
  },
  {
    id: 'contact',
    label: 'Contato',
    icon: 'Phone',
    emoji: '☎️',
    path: '/contato',
    category: MenuCategory.COMMUNICATION,
    roles: [UserRole.GUEST],
    description: 'Fale conosco',
    color: '#14B8A6'
  },

  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  // 🎫 SUPORTE
  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  {
    id: 'tickets',
    label: 'Tickets',
    icon: 'Inbox',
    emoji: '📮',
    path: '/tickets',
    category: MenuCategory.SUPPORT,
    roles: [UserRole.ADMIN, UserRole.HOST, UserRole.AGENCY, UserRole.AGENT, UserRole.GUEST],
    description: 'Suporte técnico',
    color: '#F97316'
  },

  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  // 💳 PAGAMENTOS
  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  {
    id: 'split-payments',
    label: 'Divisão de Pagamento',
    icon: 'CreditCard',
    emoji: '💳',
    path: '/split-payment',
    category: MenuCategory.PAYMENTS,
    roles: [UserRole.GUEST, UserRole.AGENT],
    description: 'Dividir contas',
    color: '#10B981',
    isHot: true
  },

  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  // 🎁 FIDELIDADE
  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  {
    id: 'loyalty',
    label: 'Programa de Fidelidade',
    icon: 'Gift',
    emoji: '🎁',
    path: '/fidelidade',
    category: MenuCategory.LOYALTY,
    roles: [UserRole.ADMIN, UserRole.GUEST],
    description: 'Pontos e benefícios',
    color: '#EC4899'
  },
  {
    id: 'rewards',
    label: 'Recompensas',
    icon: 'Trophy',
    emoji: '🏅',
    path: '/loyalty/rewards',
    category: MenuCategory.LOYALTY,
    roles: [UserRole.GUEST],
    description: 'Catálogo de rewards',
    color: '#EC4899'
  },

  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  // 🛡️ SEGUROS
  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  {
    id: 'insurance',
    label: 'Seguros',
    icon: 'Shield',
    emoji: '🛡️',
    path: '/insurance',
    category: MenuCategory.INSURANCE,
    roles: [UserRole.ADMIN, UserRole.GUEST, UserRole.AGENT],
    description: 'Proteção de viagem',
    color: '#8B5CF6'
  },
  {
    id: 'insurance-policies',
    label: 'Políticas',
    icon: 'FileText',
    emoji: '📋',
    path: '/insurance/policies',
    category: MenuCategory.INSURANCE,
    roles: [UserRole.ADMIN, UserRole.GUEST],
    description: 'Apólices de seguro',
    color: '#8B5CF6'
  },

  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  // 🔑 CHECK-IN
  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  {
    id: 'checkin',
    label: 'Check-in Digital',
    icon: 'Key',
    emoji: '🔑',
    path: '/checkin',
    category: MenuCategory.CHECKIN,
    roles: [UserRole.ADMIN, UserRole.HOST, UserRole.GUEST],
    description: 'Check-in online',
    color: '#06B6D4',
    isNew: true
  },
  {
    id: 'checkin-scan',
    label: 'Escanear QR',
    icon: 'QrCode',
    emoji: '📱',
    path: '/checkin/scan',
    category: MenuCategory.CHECKIN,
    roles: [UserRole.HOST, UserRole.GUEST],
    description: 'QR code check-in',
    color: '#06B6D4'
  },

  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  // ✅ VERIFICAÇÃO
  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  {
    id: 'verification',
    label: 'Verificação',
    icon: 'CheckCircle',
    emoji: '✅',
    path: '/verification',
    category: MenuCategory.VERIFICATION,
    roles: [UserRole.ADMIN, UserRole.HOST],
    description: 'Validar usuários',
    color: '#10B981'
  },

  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  // 📄 CONTEÚDO
  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  {
    id: 'privacy-policy',
    label: 'Política de Privacidade',
    icon: 'Shield',
    emoji: '🔒',
    path: '/politica-privacidade',
    category: MenuCategory.CONTENT,
    roles: [UserRole.ADMIN, UserRole.HOST, UserRole.AGENCY, UserRole.AGENT, UserRole.GUEST],
    description: 'Termos e política',
    color: '#6366F1'
  },

  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  // 🏷️ PROMOÇÕES
  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  {
    id: 'promotions',
    label: 'Promoções',
    icon: 'Tag',
    emoji: '🏷️',
    path: '/promocoes',
    category: MenuCategory.PROMOTIONS,
    roles: [UserRole.ADMIN, UserRole.HOST, UserRole.AGENCY, UserRole.GUEST],
    description: 'Ofertas especiais',
    color: '#EF4444',
    isHot: true
  },
  {
    id: 'coupons',
    label: 'Cupons',
    icon: 'Percent',
    emoji: '🎟️',
    path: '/cupons',
    category: MenuCategory.PROMOTIONS,
    roles: [UserRole.ADMIN, UserRole.GUEST],
    description: 'Cupons de desconto',
    color: '#EF4444'
  },

  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  // ⚙️ ADMINISTRAÇÃO (ADMIN ONLY)
  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  {
    id: 'admin-dashboard',
    label: 'Admin Dashboard',
    icon: 'LayoutDashboard',
    emoji: '🎛️',
    path: '/admin/dashboard',
    category: MenuCategory.ADMIN,
    roles: [UserRole.ADMIN],
    description: 'Painel administrativo',
    color: '#64748B'
  },
  {
    id: 'admin-cms',
    label: 'CMS',
    icon: 'FileText',
    emoji: '📝',
    path: '/admin/cms',
    category: MenuCategory.ADMIN,
    roles: [UserRole.ADMIN],
    description: 'Gerenciar conteúdo',
    color: '#64748B'
  },
  {
    id: 'admin-crm',
    label: 'CRM Admin',
    icon: 'Users',
    emoji: '👥',
    path: '/admin/crm',
    category: MenuCategory.ADMIN,
    roles: [UserRole.ADMIN],
    description: 'Gestão de usuários',
    color: '#64748B'
  },
  {
    id: 'admin-tickets',
    label: 'Tickets Admin',
    icon: 'Inbox',
    emoji: '📮',
    path: '/admin/tickets',
    category: MenuCategory.ADMIN,
    roles: [UserRole.ADMIN],
    description: 'Gerenciar tickets',
    color: '#64748B'
  },
  {
    id: 'admin-analytics',
    label: 'Analytics Admin',
    icon: 'BarChart',
    emoji: '📊',
    path: '/admin/analytics',
    category: MenuCategory.ADMIN,
    roles: [UserRole.ADMIN],
    description: 'Analytics avançado',
    color: '#64748B'
  },
  {
    id: 'admin-logs',
    label: 'Logs',
    icon: 'FileSearch',
    emoji: '🔍',
    path: '/admin/logs',
    category: MenuCategory.ADMIN,
    roles: [UserRole.ADMIN],
    description: 'Logs do sistema',
    color: '#64748B'
  },
  {
    id: 'admin-health',
    label: 'Health Monitor',
    icon: 'Activity',
    emoji: '💚',
    path: '/admin/health',
    category: MenuCategory.ADMIN,
    roles: [UserRole.ADMIN],
    description: 'Status do sistema',
    color: '#64748B'
  },

  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  // 🔧 CONFIGURAÇÕES
  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  {
    id: 'profile',
    label: 'Perfil',
    icon: 'User',
    emoji: '👤',
    path: '/perfil',
    category: MenuCategory.SETTINGS,
    roles: [UserRole.ADMIN, UserRole.HOST, UserRole.AGENCY, UserRole.AGENT, UserRole.GUEST],
    description: 'Meu perfil',
    color: '#6B7280'
  },
  {
    id: 'onboarding',
    label: 'Onboarding',
    icon: 'Rocket',
    emoji: '🚀',
    path: '/onboarding',
    category: MenuCategory.SETTINGS,
    roles: [UserRole.ADMIN, UserRole.HOST, UserRole.AGENCY, UserRole.AGENT, UserRole.GUEST],
    description: 'Tour inicial',
    color: '#6B7280'
  }
];

/**
 * ═══════════════════════════════════════════════════════════
 * 🎯 FUNÇÕES UTILITÁRIAS
 * ═══════════════════════════════════════════════════════════
 */

/**
 * Filtrar menu por perfil de usuário
 */
export function getMenuByRole(role: UserRole): MenuItem[] {
  return COMPLETE_MENU.filter(item => item.roles.includes(role));
}

/**
 * Filtrar menu por categoria
 */
export function getMenuByCategory(category: MenuCategory, role?: UserRole): MenuItem[] {
  let items = COMPLETE_MENU.filter(item => item.category === category);
  
  if (role) {
    items = items.filter(item => item.roles.includes(role));
  }
  
  return items;
}

/**
 * Obter categorias disponíveis para um perfil
 */
export function getCategoriesByRole(role: UserRole): MenuCategoryConfig[] {
  return MENU_CATEGORIES.filter(cat => cat.roles.includes(role));
}

/**
 * Obter item do menu por ID
 */
export function getMenuItemById(id: string): MenuItem | undefined {
  return COMPLETE_MENU.find(item => item.id === id);
}

/**
 * Obter badge count (simulado - seria integrado com API real)
 */
export function getBadgeCount(itemId: string): number {
  // Simular badges para demo
  const badges: Record<string, number> = {
    'my-bookings': 3,
    'messages': 5,
    'notifications': 12,
    'group-chats': 2
  };
  
  return badges[itemId] || 0;
}

/**
 * Verificar se item é novo
 */
export function isNewItem(itemId: string): boolean {
  const item = getMenuItemById(itemId);
  return item?.isNew || false;
}

/**
 * Verificar se item está em destaque (hot)
 */
export function isHotItem(itemId: string): boolean {
  const item = getMenuItemById(itemId);
  return item?.isHot || false;
}

/**
 * Agrupar menu por categoria
 */
export function getGroupedMenu(role?: UserRole): Record<MenuCategory, MenuItem[]> {
  const grouped: Record<string, MenuItem[]> = {};
  
  let items = COMPLETE_MENU;
  if (role) {
    items = getMenuByRole(role);
  }
  
  items.forEach(item => {
    if (!grouped[item.category]) {
      grouped[item.category] = [];
    }
    grouped[item.category].push(item);
  });
  
  return grouped as Record<MenuCategory, MenuItem[]>;
}

/**
 * Buscar itens do menu
 */
export function searchMenu(query: string, role?: UserRole): MenuItem[] {
  const lowerQuery = query.toLowerCase();
  
  let items = COMPLETE_MENU;
  if (role) {
    items = getMenuByRole(role);
  }
  
  return items.filter(item => 
    item.label.toLowerCase().includes(lowerQuery) ||
    item.description?.toLowerCase().includes(lowerQuery) ||
    item.path.toLowerCase().includes(lowerQuery)
  );
}

/**
 * Obter menu hierárquico (para sidebar)
 */
export interface HierarchicalMenu {
  category: MenuCategoryConfig;
  items: MenuItem[];
}

export function getHierarchicalMenu(role: UserRole): HierarchicalMenu[] {
  const categories = getCategoriesByRole(role);
  const grouped = getGroupedMenu(role);
  
  return categories
    .map(category => ({
      category,
      items: grouped[category.id] || []
    }))
    .filter(group => group.items.length > 0);
}

/**
 * ═══════════════════════════════════════════════════════════
 * 📊 ESTATÍSTICAS DO MENU
 * ═══════════════════════════════════════════════════════════
 */
export const MENU_STATS = {
  TOTAL_ITEMS: COMPLETE_MENU.length,
  TOTAL_CATEGORIES: MENU_CATEGORIES.length,
  ITEMS_BY_ROLE: {
    [UserRole.ADMIN]: getMenuByRole(UserRole.ADMIN).length,
    [UserRole.HOST]: getMenuByRole(UserRole.HOST).length,
    [UserRole.AGENCY]: getMenuByRole(UserRole.AGENCY).length,
    [UserRole.AGENT]: getMenuByRole(UserRole.AGENT).length,
    [UserRole.GUEST]: getMenuByRole(UserRole.GUEST).length
  },
  NEW_ITEMS: COMPLETE_MENU.filter(item => item.isNew).length,
  HOT_ITEMS: COMPLETE_MENU.filter(item => item.isHot).length,
  ITEMS_WITH_BADGES: COMPLETE_MENU.filter(item => item.badge).length
};

console.log('📊 RSV Menu Structure Loaded:', MENU_STATS);
